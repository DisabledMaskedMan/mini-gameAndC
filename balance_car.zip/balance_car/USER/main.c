#include "stm32f4xx.h"                  // Device header
#include "sys.h"
#include "bmp.h"
//#include "string.h"
//stm32f407vgt6��Ƶ168MS

int16_t Target_left=0,Target_right=0;	//��λ��mm
extern float sum;	//����ߵ�Ȧ������TIM5�У�
extern float LUC;	//·�̣���TIM5�У�
extern float VE;	//�ٶȣ���TIM5�У�
extern int divert;
extern int turn_flag,turn_end;
extern uint8_t U4Flag;

extern float Movement;
extern float Goal_Angle;
extern float Tmp_Angle;

//float orient;//ȫ�ֱ����Ƕ�

enum STATE
{
	Forward = 1,
	Backward,
	Left,
	Right,
	STOP,
};

int main(void)
{
	OLED_Init();
	
//	My_I2C_Init();
//	MPU6050Init();			//Ʈ���е���
	MPU_Init();		//��ʼ��MPU6050
	while(mpu_dmp_init())
 	{
		OLED_ShowString(3, 1, "MPU6050 error");
		Delay_ms(200);
	} 
	OLED_ShowString(3, 1, "OK              ");
//	GestureTime_Init();		//������
	TIM3_PI_Init();
	Serial_Init();	//����
	Motor_Init();	//�������ת��PWM����
//	Time5_Init();	//�жϴ��������PWM���㣩		2500mm/s 10ms��25mm		//�������ж�100ms
	TIM9_PWM_Init(8400-1,2-1);
	Encoder_left_Init();
	Encoder_right_Init();
	PID_left_Init(2,1.5,0);			//Ҫ�ģ�����ֵתPWMֵ��PWMֵ0-100��
	PID_right_Init(2,1.5,0);
//	PID_track_Init(0.2,0,0);		//0.2��0��0
	PID_turn_Init(0.38,0,0);		
	PID_position_Init(1,0,0);
//	Fuzzy_Init(90, -90, 10, -10, 370, -370, 0, 0, 0, 0);
	
//	UL_Init();
	while(1)
	{
//		Motor(8400, 8400);
//		int Ve = LUC/0.01;
//		OLED_ShowSignedNum(2, 1, LUC, 5);
//		OLED_ShowSignedNum(1, 1, VE, 5);
//		OLED_ShowSignedNum(2, 1, U4Flag, 5);
		switch (U4Flag)
		{
			case Forward:
				Movement+=10;
//				if (Movement >= 50)
//					Movement = 50;
				U4Flag = 0;
				break;
			case Backward:
				Movement-=10;
//				if (Movement <= -50)
//					Movement = -50;
				U4Flag = 0;
				break;
			case Left:
				Tmp_Angle-=5;
				if (Tmp_Angle >= 180)
					Tmp_Angle -= 360;
				U4Flag = 0;
				break;
			case Right:
				Tmp_Angle+=5;
				if (Tmp_Angle <= -180)
					Tmp_Angle += 360;
				U4Flag = 0;
				break;
			case STOP:
				Movement=0;
				break;
		}
//		send_to_phone(Movement);
//		Motor(Movement, Movement);
		kernelPoll();
	}
}

