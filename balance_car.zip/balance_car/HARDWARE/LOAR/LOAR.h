#ifndef _LOAR_H
#define _LOAR_H
#include "sys.h"

void LOAR_Init(void);
void Loar_SendByte(uint8_t Byte);
void Loar_Init(void);
void Loar_SendArry(uint8_t *Array,uint16_t Length);
void Loar_SendString(char *String);
void Loar_SendNumber(uint32_t Number,uint8_t Length);
//void Loar_Printf(char *format,...);
uint8_t Loar_GetRxFlag(void);
uint8_t Loar_GetRxData(void);

#endif
