#include "stm32f4xx.h"                  // Device header
#include <cstdio>
#include <stdarg.h>

uint8_t Loar_RxData;
uint8_t Loar_RxFlag;

void LOAR_Init(void)
{
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC|RCC_AHB1Periph_GPIOD,ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART5,ENABLE);
	
	GPIO_PinAFConfig(GPIOC,GPIO_PinSource12,GPIO_AF_UART5);
	GPIO_PinAFConfig(GPIOD,GPIO_PinSource2,GPIO_AF_UART5);
	
	GPIO_InitTypeDef GPIO_InitStruct;
	
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_AF;
	GPIO_InitStruct.GPIO_OType=GPIO_OType_PP;
	GPIO_InitStruct.GPIO_Pin=GPIO_Pin_12;			//TX
	GPIO_InitStruct.GPIO_PuPd=GPIO_PuPd_UP;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_100MHz;
	GPIO_Init(GPIOC,&GPIO_InitStruct);
	
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_AF;
	GPIO_InitStruct.GPIO_OType=GPIO_OType_PP;
	GPIO_InitStruct.GPIO_Pin=GPIO_Pin_2;			//RX
	GPIO_InitStruct.GPIO_PuPd=GPIO_PuPd_UP;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_100MHz;
	GPIO_Init(GPIOD,&GPIO_InitStruct);
	
	USART_InitTypeDef  USART_InitStruct;
	USART_InitStruct.USART_BaudRate = 9600;
	USART_InitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStruct.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
	USART_InitStruct.USART_Parity = USART_Parity_No;
	USART_InitStruct.USART_StopBits = USART_StopBits_1;
	USART_InitStruct.USART_WordLength = USART_WordLength_8b;
	USART_Init(UART5,&USART_InitStruct);
	
	
	USART_ITConfig(UART5,USART_IT_RXNE,ENABLE);
	
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = UART5_IRQn;
     NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
     NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=2;			//����0 ѭ��1 loar2
     NVIC_InitStructure.NVIC_IRQChannelSubPriority=0;
     NVIC_Init(&NVIC_InitStructure); 
     
     USART_Cmd(UART5,ENABLE);
	///////////////////////      дLOAT��M0��M1        ///////////////////////////////
	
	
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_OUT;
	GPIO_InitStruct.GPIO_OType=GPIO_OType_PP;
	GPIO_InitStruct.GPIO_Pin=GPIO_Pin_0;			//TX
	GPIO_InitStruct.GPIO_PuPd=GPIO_PuPd_UP;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_100MHz;
	GPIO_Init(GPIOC,&GPIO_InitStruct);
	
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_OUT;
	GPIO_InitStruct.GPIO_OType=GPIO_OType_PP;
	GPIO_InitStruct.GPIO_Pin=GPIO_Pin_5;			//RX
	GPIO_InitStruct.GPIO_PuPd=GPIO_PuPd_UP;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_100MHz;
	GPIO_Init(GPIOC,&GPIO_InitStruct);
	
	GPIO_ResetBits(GPIOC,GPIO_Pin_0|GPIO_Pin_5);
	
}


void Loar_SendByte(uint8_t Byte)
{
	USART_SendData(UART5,Byte);
	while(USART_GetFlagStatus(UART5,USART_FLAG_TXE)==RESET);
	
}


void Loar_SendArry(uint8_t *Array,uint16_t Length)
{
	uint16_t i;
	for (i=0;i<Length;i++)
	{
		Loar_SendByte(Array[i]);
		
	}
}

void Loar_SendString(char *String)
{
	uint8_t i;
	for(i=0;String[i]!='\0';i++)
	{
		Loar_SendByte(String[i]);
	}
}

uint32_t Loar_Pow(uint32_t x,uint32_t y)
{
	uint32_t result = 1;
	while(y--)
	{
		result = result* x;
	}
	return result;
}

void Loar_SendNumber(uint32_t Number,uint8_t Length)
{
	uint16_t i;
	for(i=0;i<Length;i++)
	{
		Loar_SendByte(Number/Loar_Pow(10,Length-i-1)%10 + 0x30);
	}
	
}
	
//void Loar_Printf(char *format,...)
//{
//	char String[100];
//	va_list arg;
//	va_start(arg,format);
//	vsprintf(String,format,arg);
//	va_end(arg);
//	Loar_SendString(String);
//}

uint8_t Loar_GetRxFlag(void)
{
	if(Loar_RxFlag == 1)
	{
		Loar_RxFlag=0;
		return 1;
	}
	return 0;
}

uint8_t Loar_GetRxData(void)
{
	return Loar_RxData;
}


void UART5_IRQHandler(void)
{
	if(USART_GetFlagStatus(UART5,USART_FLAG_RXNE)==SET)
	{
		Loar_RxData=USART_ReceiveData(UART5);
	     Loar_RxFlag = 1;
	     USART_ClearFlag(UART5,USART_IT_RXNE);
		
	}
	else if(USART_GetFlagStatus(UART5,USART_FLAG_RXNE)==SET)
	{
		;
	}
}


