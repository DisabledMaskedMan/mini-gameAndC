#ifndef _MOTOR_H
#define _MOTOR_H
#include "sys.h"
 	
void Motor_Init(void);
void Motor(int16_t pwm_left,int16_t pwm_right);

#endif
