#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "pwm.h"
#include "Motor.h"

//���� PE8 PE7
//���� PE9 PE10

void  Motor_Init(void)
{
  GPIO_InitTypeDef  GPIO_InitStructure;

  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE, ENABLE);//ʹ��GPIOFʱ��

  //GPIOE7,E8,E9,E10��ʼ������
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7 | GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10;//PE8 AIN1	PE7 AIN8	PE9 BIN1	PE10 BIN2
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;//��ͨ���ģʽ
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;//�������
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;//100MHz
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;//����
  GPIO_Init(GPIOE, &GPIO_InitStructure);//��ʼ��GPIO	
//  GPIO_SetBits(GPIOE,GPIO_Pin_7 | GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10);//GPIOF9,F10���øߣ�����

}

void Motor(int16_t pwm_left,int16_t pwm_right)
{
	if(pwm_right>0)
	{
		TIM_SetCompare2(TIM9,pwm_right);
		GPIO_SetBits(GPIOE,GPIO_Pin_9);
		GPIO_ResetBits(GPIOE,GPIO_Pin_10);//���� 0 1
	}
	else
	{
		TIM_SetCompare2(TIM9,-pwm_right);
		GPIO_SetBits(GPIOE,GPIO_Pin_10);
		GPIO_ResetBits(GPIOE,GPIO_Pin_9);//���� 1 0
	}
	if(pwm_left>0)
	{
		TIM_SetCompare1(TIM9,pwm_left);
		GPIO_SetBits(GPIOE,GPIO_Pin_8);
		GPIO_ResetBits(GPIOE,GPIO_Pin_7);//���� 0 1
	}
	else
	{
		TIM_SetCompare1(TIM9,-pwm_left);
		GPIO_SetBits(GPIOE,GPIO_Pin_7);
		GPIO_ResetBits(GPIOE,GPIO_Pin_8);//���� 1 0
	}
}

