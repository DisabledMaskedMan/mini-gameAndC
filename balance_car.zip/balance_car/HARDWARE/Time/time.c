#include "stm32f4xx.h"                  // Device header
#include "sys.h"

int32_t Encoder_left,Encoder_right;
int16_t current_left,current_right;
float sum=0;
int divert=0;
extern int16_t Target_left,Target_right;

float LUC=0;
float VE=0;

extern int turn_end;
extern uint8_t ULT_RUN;

void Time5_Init(void)	//100ms
{
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5, ENABLE);
	
	TIM_InternalClockConfig(TIM5);
	
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInitStructure.TIM_Period = 20000 - 1;
	TIM_TimeBaseInitStructure.TIM_Prescaler = 840 - 1;
	TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM5, &TIM_TimeBaseInitStructure);
	
	TIM_ClearFlag(TIM5, TIM_FLAG_Update);
	TIM_ITConfig(TIM5, TIM_IT_Update, ENABLE);
	
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = TIM5_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_Init(&NVIC_InitStructure);
	
	TIM_Cmd(TIM5, ENABLE);
}

void TIM5_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM5,TIM_IT_Update)==SET)  // �жϱ�־λ��1
	{	
		ULT_RUN = 1;
//		TIM_ClearITPendingBit(TIM5,TIM_IT_Update);  // ����жϱ�־λ
//		Encoder_right=(int)(Encoder1_Get());
//		TIM_SetCounter(TIM1, 0);	
//		Encoder_left=(int)(Encoder2_Get());
//		TIM_SetCounter(TIM2, 0);
//		
////		OLED_ShowSignedNum(1, 1, Encoder_right, 5);
////		OLED_ShowSignedNum(1, 7, Encoder_left, 5);
//		
////		LUC = (((int)(Encoder_left+Encoder_right)/2640.0)*2*3.1416*32.5);
//		VE = Encoder_left+Encoder_right;
//		
//		//ֱ�����ٵ�����������������õ��ı���ֵ���ڼ��ٱȣ��ٳ�����ٺ����������
//		sum+=(((int)(Encoder_left+Encoder_right)/2640.0)*2*3.1416*32.5);		//mm 30���ٱ� 13���� 4��Ƶ
////		sum+=((int)(Encoder_left+Encoder_right)/660.0);
//		current_left  =(int)PID_calculation_left(Encoder_left,Target_left);
//		current_right =(int)PID_calculation_right(Encoder_right,Target_right);
//		
//		//Motor(current_left,current_right);
	}
}
