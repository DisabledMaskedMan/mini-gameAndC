#ifndef __program_interrupt_H_
#define __program_interrupt_H_

#include "stm32f4xx.h"                  // Device header
#include "sys.h"

typedef struct{
    int16_t accX;
    int16_t accY;
    int16_t accZ;
    int16_t gyroX;
    int16_t gyroY;
    int16_t gyroZ;
    
    int16_t Offset[6];		//��ƽ״̬�µ�ƫ��
    uint8_t Check;		
}MPU6050Manager_t;

typedef struct{
    float roll;
    float pitch;
    float yaw;
}Attitude_t;

void TIM3_PI_Init(void);

#endif
