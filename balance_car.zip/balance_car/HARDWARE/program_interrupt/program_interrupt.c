#include "program_interrupt.h"                  // Device header
//#include "mpu6050.h"
//#include "imu.h"

//extern uint32_t _cnt_;
//extern bool KernelRunning;

int Flag_control=0;//�����Ƿ���ƣ��Ƕ�5ms�ɼ�һ�� ֱ�����ͽǶȻ�10ms����һ�Σ�

Attitude_t g_Attitude;    //��ǰ�Ƕ���ֵ̬
MPU6050Manager_t g_MPUManager;   //g_MPUManagerԭʼ����

extern short MY_GYRO[3];
extern Attitude_t g_Attitude;
extern int ULT_Distance;
extern int ULT_PWM;

int balance_Pwm;
int Velocity_Pwm;
int Turn_Pwm;
int ZongPwmL;
int ZongPwmR;

void TIM3_PI_Init(void)         //TIM9��ͨ��1��ͨ��2��pwmA��pwmB����	5ms
{		 					 
	//�˲������ֶ��޸�IO������
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
	
	TIM_InternalClockConfig(TIM3);
	
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInitStructure.TIM_Period = 1000 - 1;
	TIM_TimeBaseInitStructure.TIM_Prescaler = 840 - 1;
	TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseInitStructure);
	
	TIM_ClearFlag(TIM3, TIM_FLAG_Update);
	TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);
	
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_Init(&NVIC_InitStructure);
	
	TIM_Cmd(TIM3, ENABLE);
}

void TIM3_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM3,TIM_IT_Update)==SET)  // �жϱ�־λ��1
	{
		Flag_control=!Flag_control;  //�����Ƿ���ƣ��Ƕ�5ms�ɼ�һ�� ֱ�����ͽǶȻ�10ms����һ�Σ�
		if(Flag_control==1)                //5ms��ȡһ�������Ǻͼ��ٶȼƵ�ֵ
		{
			mpu_dmp_get_data(&(g_Attitude.pitch),&(g_Attitude.roll),&(g_Attitude.yaw));				//===������̬	
			return;	                                               
		}
		mpu_dmp_get_data(&(g_Attitude.pitch),&(g_Attitude.roll),&(g_Attitude.yaw));
		balance_Pwm = balance(-(g_Attitude.pitch), MY_GYRO[1]);
//		balance_Pwm = 0;
		Velocity_Pwm=velocity(-(g_Attitude.pitch));
		Turn_Pwm=Turn_Balance(-(g_Attitude.yaw));
		ZongPwmL = balance_Pwm - Velocity_Pwm + Turn_Pwm;	// + ULT_Distance
		ZongPwmR = balance_Pwm - Velocity_Pwm - Turn_Pwm;	// + ULT_Distance
		if (ZongPwmL > 8400)
			ZongPwmL = 8400;
		else if(ZongPwmL < -8400)
			ZongPwmL = -8400;
		if (ZongPwmR > 8400)
			ZongPwmR = 8400;
		else if(ZongPwmR < -8400)
			ZongPwmR = -8400;
		Motor(ZongPwmL, ZongPwmR);
		TIM_ClearITPendingBit(TIM3,TIM_IT_Update);  // ����жϱ�־λ
	}
}
