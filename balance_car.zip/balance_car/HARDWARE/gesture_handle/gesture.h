//#ifndef __gesture_H_
//#define __gesture_H_

//void GestureTime_Init(void);

//#endif
