//#include "stm32f4xx.h"                  // Device header
//#include "mpu6050.h"
//#include "imu.h"

////extern void ATT_Update(const MPU6050Manager_t *pMpu,Attitude_t *pAngE, float dt);

//void GestureTime_Init(void)		//3ms
//{
//	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM7, ENABLE);
//	
//	TIM_InternalClockConfig(TIM7);
//	
//	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
//	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
//	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
//	TIM_TimeBaseInitStructure.TIM_Period = 600 - 1;
//	TIM_TimeBaseInitStructure.TIM_Prescaler = 840 - 1;
//	TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;
//	TIM_TimeBaseInit(TIM7, &TIM_TimeBaseInitStructure);
//	
//	TIM_ClearFlag(TIM7, TIM_FLAG_Update);
//	TIM_ITConfig(TIM7, TIM_IT_Update, ENABLE);
//	
//	NVIC_InitTypeDef NVIC_InitStructure;
//	NVIC_InitStructure.NVIC_IRQChannel = TIM7_IRQn;
//	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
//	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
//	NVIC_Init(&NVIC_InitStructure);
//	
//	TIM_Cmd(TIM7, ENABLE);
//}

//void TIM7_IRQHandler(void)
//{
//	if(TIM_GetITStatus(TIM7,TIM_IT_Update)==SET)  // �жϱ�־λ��1
//	{
//		GetMPU6050Data();
//		ATT_Update(&g_MPUManager, &g_Attitude, 0.003f);
//		TIM_ClearITPendingBit(TIM7,TIM_IT_Update);  // ����жϱ�־λ
//	}
//}
