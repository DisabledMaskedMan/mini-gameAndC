#include "mpu6050.h"

//����
//#define Acc_Read()          I2C_Read_Bytes(0x3B, buffer, 6) //��ȡ���ٶ�
//#define Gyro_Read()         I2C_Read_Bytes(0x43, &buffer[6], 6)  //  ��ȡ���ٶ�

//Ӳ��
//#define mpu6050Read(buffer)          MPU6050_Receive_Data(buffer) //��ȡ���ٶȺͶ�ȡ���ٶ�

//˽�б�����
MPU6050Manager_t g_MPUManager;   //g_MPUManagerԭʼ����
int16_t *pMpu = (int16_t *)&g_MPUManager; 

void MPU6050_WriteReg(uint8_t RegAddress, uint8_t Data)
{
	My_I2C_Start();
	My_I2C_W_Byte(MPU6050_ADDRESS);
	My_I2C_ReceiveAck();
	My_I2C_W_Byte(RegAddress);
	My_I2C_ReceiveAck();
	My_I2C_W_Byte(Data);
	My_I2C_ReceiveAck();
	My_I2C_End();
}

uint8_t My_MPU6050_ReadReg(uint8_t RegAddress)
{
	uint8_t Data = 0;
	
	My_I2C_Start();
	My_I2C_W_Byte(MPU6050_ADDRESS);
	My_I2C_ReceiveAck();
	My_I2C_W_Byte(RegAddress);
	My_I2C_ReceiveAck();
	
	My_I2C_Start();
	My_I2C_W_Byte(MPU6050_ADDRESS | 0x01);
	My_I2C_ReceiveAck();
	Data = My_I2C_R_Byte();
	My_I2C_SendAck(1);
	My_I2C_End();
	
	return Data;
}

//uint8_t I2C_Read_Bytes(uint8_t RegAddress, uint8_t *ptr, uint8_t len)
//{
//    My_I2C_Start();
//    My_I2C_W_Byte(MPU6050_ADDRESS);
//	My_I2C_ReceiveAck();
//	My_I2C_W_Byte(RegAddress);
//    My_I2C_ReceiveAck();
//    My_I2C_Start();
//    My_I2C_W_Byte(MPU6050_ADDRESS | 0x01);
//    My_I2C_ReceiveAck();
//    while (len)
//    {
//        if (len == 1)
//        {
//            *ptr = My_I2C_R_Byte();
//            My_I2C_SendAck(0);
//        }
//        else
//        {
//            *ptr = My_I2C_R_Byte();
//            My_I2C_SendAck(1);
//        }
//        ptr++;
//        len--;
//    }
//    My_I2C_End();
//    return 0;
//}

uint8_t MPU6050Init(void) //��ʼ��
{
    uint8_t check = 0;

    check = My_MPU6050_ReadReg(0x75);  //�ж�g_MPUManager��ַ
    if(check != 0x68) //�����ַ����ȷ
    {
        g_MPUManager.Check = 0;
        return 0;
    }
    else
    {
        Delay_ms(200);
        MPU6050_WriteReg(MPU6050_PWR_MGMT_1, 0x80);   //��λ
        Delay_ms(200);
        MPU6050_WriteReg(MPU6050_SMPLRT_DIV, 0x00);   //�����ǲ����ʣ�0x00(1000Hz)
        Delay_ms(10);
        MPU6050_WriteReg(MPU6050_PWR_MGMT_1, 0x03);   //�����豸ʱ��Դ��������Z��
        Delay_ms(10);
        MPU6050_WriteReg(MPU6050_CONFIG, 0x04);   //��ͨ�˲�Ƶ�ʣ�0x03(42Hz)
        Delay_ms(10);
        MPU6050_WriteReg(MPU6050_GYRO_CONFIG, 0x18);   //+-2000deg/s
        Delay_ms(10);
        MPU6050_WriteReg(MPU6050_ACCEL_CONFIG, 0x18);   //+-16
        Delay_ms(10);
        
        GetMPU6050Offset(); //����У׼����
        g_MPUManager.Check = 1;
        return 1;
    }
}

void MPU6050_Receive_Data(int16_t* Arrz)
{
	uint8_t i = 0;
	uint8_t j = 0;
	uint8_t Arr[12] = {0};
	for(i = 0; i < 6; i++)
		Arr[i] = My_MPU6050_ReadReg(MPU6050_ACCEL_XOUT_H + i);
	for(i = 6, j = 0; i < 12; i++, j++)
		Arr[i] = My_MPU6050_ReadReg(MPU6050_GYRO_XOUT_H + j);
	for(i = 0, j = 0; i < 12; i+=2, j++)
		Arrz[j] = (Arr[i] << 8) | Arr[i+1];
}

void MPU6050_Receive_DataV2(uint8_t* Arr)
{
	uint8_t i = 0;
	uint8_t j = 0;
	for(i = 0; i < 6; i++)
		Arr[i] = My_MPU6050_ReadReg(MPU6050_ACCEL_XOUT_H + i);
	for(i = 6, j = 0; i < 12; i++, j++)
		Arr[i] = My_MPU6050_ReadReg(MPU6050_GYRO_XOUT_H + j);
}

//uint32_t test_6050time[3];
void GetMPU6050Data(void) 
{
    static float mpu_filter[2][6];
    int16_t mpu_filter_tmp[6];
    uint8_t buffer[12];

//��ȡ���ٶȼ����ݺ�����������
//����
//    Acc_Read();
//    Gyro_Read();
	MPU6050_Receive_DataV2(buffer);

//Ӳ��
//	mpu6050Read(buffer);

    for(int i = 0; i < 6; i++)
    {
        //ƴ�Ӷ�ȡ����ԭʼ����
        mpu_filter_tmp[i] = (((int16_t)buffer[i << 1] << 8) | buffer[(i << 1) + 1])
                - g_MPUManager.Offset[i];

        //ԭʼ����LPF
        mpu_filter[0][i] += 0.3f *(mpu_filter_tmp[i] - mpu_filter[0][i]);
        mpu_filter[1][i] += 0.3f *(mpu_filter[0][i]  - mpu_filter[1][i]);

        //��ֵ���ṹ��
        pMpu[i] = (int16_t)mpu_filter[1][i];
    }

//	OLED_ShowSignedNum(2, 1, mpu_filter[0][0], 5);
//	OLED_ShowSignedNum(3, 1, mpu_filter[0][1], 5);
//	OLED_ShowSignedNum(4, 1, mpu_filter[0][2], 5);
//	OLED_ShowSignedNum(2, 8, mpu_filter[1][0], 5);
//	OLED_ShowSignedNum(3, 8, mpu_filter[1][1], 5);
//	OLED_ShowSignedNum(4, 8, mpu_filter[1][2], 5);
}

void GetMPU6050Offset(void) //У׼
{
    int32_t buffer[6] = { 0 };
    int16_t i = 0;  

    
    memset(g_MPUManager.Offset, 0, 12);
    g_MPUManager.Offset[2] = 2048;   //�����ֲ������趨���ٶȱ궨ֵ 

    //����ǰ300������
    for(int i = 0;i < 300;i++)
    {   
        Delay_ms(2);
        GetMPU6050Data();
    }

    //ȡ��100����356���ƽ��ֵ��ΪУ׼ֵ
    for(i = 0; i < 356; i++)  
    {
        GetMPU6050Data();
        
        if(100 <= i)
        {
            for(int k = 0; k < 6; k++)
            {
                buffer[k] += pMpu[k];
            }
        }
    }

    //����У׼ֵ
    for(i = 0; i < 6; i++)
    {
        //����8λ�����ݳ���256
        g_MPUManager.Offset[i] = buffer[i] >> 8;
    }
	OLED_ShowString(4, 1, "InitOK");
}
