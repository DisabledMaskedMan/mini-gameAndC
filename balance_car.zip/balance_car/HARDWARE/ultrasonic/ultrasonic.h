#ifndef __ultrasonic_H_
#define __ultrasonic_H_

void UL_Init(void);

#endif
