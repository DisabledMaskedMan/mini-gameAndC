#include "stm32f4xx.h"                  // Device header
#include "mpu6050IIC.h"

void My_I2C_Write_SCL(uint8_t BitVal)
{
	GPIO_WriteBit(GPIOG, GPIO_Pin_8, (BitAction)BitVal);
	Delay_us(10);
}

void My_I2C_Write_SDA(uint8_t BitVal)
{
	GPIO_WriteBit(GPIOG, GPIO_Pin_6, (BitAction)BitVal);
	Delay_us(10);
}

uint8_t My_I2C_Read_SDA(void)
{
	uint8_t Data = 0;
	Data = GPIO_ReadInputDataBit(GPIOG, GPIO_Pin_6);
	Delay_us(10);
	return Data;
}

void My_I2C_Init(void)
{
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOG,ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;//100M
    GPIO_Init(GPIOG, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;//100M
    GPIO_Init(GPIOG, &GPIO_InitStructure);
	
	GPIO_SetBits(GPIOG, GPIO_Pin_6 | GPIO_Pin_8);
}

void My_I2C_Start(void)
{
	My_I2C_Write_SDA(1);
	My_I2C_Write_SCL(1);
	My_I2C_Write_SDA(0);
	My_I2C_Write_SCL(0);
}

void My_I2C_End(void)
{
	My_I2C_Write_SDA(0);
	My_I2C_Write_SCL(1);
	My_I2C_Write_SDA(1);
}

void My_I2C_W_Byte(uint8_t Data)
{
	uint8_t i = 0;
	for(i = 0; i < 8; i++)
	{
		My_I2C_Write_SDA(Data & (0x80 >> i));
		My_I2C_Write_SCL(1);
		My_I2C_Write_SCL(0);
	}
}

uint8_t My_I2C_ReceiveAck(void)
{
	uint8_t AckData = 0;
	My_I2C_Write_SDA(1);
	My_I2C_Write_SCL(1);
	AckData = My_I2C_Read_SDA();
	My_I2C_Write_SCL(0);
	return AckData;
}

uint8_t My_I2C_R_Byte(void)
{
	uint8_t i, Data = 0;
	My_I2C_Write_SDA(1);
	for(i = 0; i < 8; i++)
	{
		My_I2C_Write_SCL(1);
		if(My_I2C_Read_SDA())
			Data |= (0x80 >> i);
		My_I2C_Write_SCL(0);
	}
	return Data;
}

void My_I2C_SendAck(uint8_t Data)
{
	My_I2C_Write_SDA(Data);
	My_I2C_Write_SCL(1);
	My_I2C_Write_SCL(0);
}
