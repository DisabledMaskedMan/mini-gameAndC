#ifndef __mpu6050IIC_H_
#define __mpu6050IIC_H_

#include "Delay.h"

void My_I2C_Init(void);
void My_I2C_Start(void);
void My_I2C_End(void);
void My_I2C_W_Byte(uint8_t Data);
uint8_t My_I2C_ReceiveAck(void);
uint8_t My_I2C_R_Byte(void);
void My_I2C_SendAck(uint8_t Data);


#endif
