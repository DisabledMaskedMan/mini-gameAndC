#ifndef __DIRECTION1_H
#define __DIRECTION1_H

void car_go(int mod, int target);
void turn_read(void);
void stop(void);
void turn(float angle);
void check_turn_cross(void);
void check_turn_right(void);
void check_over(void);
void check_cross(void);

#endif
