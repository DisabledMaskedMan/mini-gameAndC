#include "stm32f4xx.h"                  // Device header
#include "sys.h"

extern int32_t Encoder_left,Encoder_right;
extern int16_t Target_left,Target_right;
extern int16_t current_left,current_right;
extern int divert;
extern float sum;

int turn_end=0;     //ת���־λ ת�������־λ
float Last_orient;
extern float orient;

/******�˲���־λ******/
char over_flag=0,over_count=0,over_index=0,over_temp=0;
char right_flag=0,right_count=0,right_index=0,right_temp=0;
void turn_read(void)		//�ѵ�ǰ�ǶȺ�Ҫת�ĽǶȶ���ȥ
{
//		Last_orient = ((float)stcAngle.Angle[2]/32768*180); 	//��ǰ�Ƕ�		
		turn_end  = 1;									//��ʼʹ��turn����

}

void car_go(int mod, int target)
{
	sum=0;
	while(sum<=target)
	{
		PID_calculation(mod,target);
	}
	
	Target_left=0,Target_right=0;
	
}


void turn(float angle)
{
	turn_read();
	while(turn_end)
	{
		PID_calculation(1,angle);
	}
	
}

void stop(void)
{
	Target_left =0;
	Target_right=0;
}
void check_cross(void)
{
	while(!((GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_0)==RESET)&&(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_1)==RESET)&&
			(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_0)==RESET)&&(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_1)==RESET)&&
			(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_2)==RESET)&&(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_3)==RESET)&&
			(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_4)==RESET)))
	{
		PID_calculation(2,20);
	}
	sum=0;
	while(sum<40)
	{
		Target_left =15;
		Target_right=15;
	}
		Target_left =0;
		Target_right=0;
}

void check_turn_cross(void)
{
	while(!((GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_0)==RESET)&&(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_1)==RESET)&&
			(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_0)==RESET)&&(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_1)==RESET)&&
			(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_2)==RESET)&&(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_3)==RESET)&&
			(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_4)==RESET)))
	{
//		PID_calculation(2,20);
		Target_left =20;
		Target_right=20;
	}
	sum=0;
	while(sum<40)
	{
		Target_left =15;
		Target_right=15;
	}
		Target_left =0;
		Target_right=0;
}

void check_turn_right(void)
{
	while(!((GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_0)==SET)&&(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_1)==SET)&&
			(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_3)==RESET)&&(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_2)==RESET)))
	{
		PID_calculation(0,30);
	}
	sum=0;
	while(sum<80)
	{
		Target_left =15;
		Target_right=15;
	}
}

void check_turn_left(void)
{
	;
}

void check_over(void)
{
	over_flag=0;
	over_index=0;
	while(!over_flag)
	{
		if(((GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_0)==SET)&&(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_1)==SET)&&
			(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_0)==SET)&&(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_1)==SET)&&
			(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_2)==SET)&&(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_3)==SET)&&
			(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_4)==SET)))
			{
				over_count=1;
				if(over_count==over_temp)
				{
					over_index++;
					if(over_index>=15)
						over_flag=1;
				}
				else
				{
					over_index=0;
				}
				over_temp=over_count;
			}
		
		PID_calculation(2,40);
//		printf("1");
	}
		Target_left =0;
		Target_right=0;
}
