#include "stm32f4xx.h"                  // Device header
#include <cstdio>
#include <stdarg.h>
#include "OLED.h"
#include "Serial.h" 

uint8_t Serial_RxData;
uint8_t Serial_RxFlag;
uint8_t U4Flag;
uint8_t U4Mode;

void Serial_Init(void)
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4,ENABLE);			//UART �� USART������
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC,ENABLE);			//IO��Ҫѡ�ԣ�����ҲҪѡ�Բ��ᱨ��������UART��ѡ��
	
	GPIO_PinAFConfig(GPIOC,GPIO_PinSource10,GPIO_AF_UART4);		//һ��Ҫ����
    GPIO_PinAFConfig(GPIOC,GPIO_PinSource11,GPIO_AF_UART4);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_10;				//TX
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_100MHz;
	GPIO_InitStructure.GPIO_OType=GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd=GPIO_PuPd_UP;
	GPIO_Init(GPIOC,&GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_11;			//RX
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_100MHz;
	GPIO_InitStructure.GPIO_OType=GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd=GPIO_PuPd_UP;
	GPIO_Init(GPIOC,&GPIO_InitStructure);
	
	USART_InitTypeDef  USART_InitStruct;
	USART_InitStruct.USART_BaudRate = 9600;
	USART_InitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStruct.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
	USART_InitStruct.USART_Parity = USART_Parity_No;
	USART_InitStruct.USART_StopBits = USART_StopBits_1;
	USART_InitStruct.USART_WordLength = USART_WordLength_8b;
	USART_Init(UART4,&USART_InitStruct);
	

	USART_ITConfig(UART4,USART_IT_RXNE,ENABLE);
	 
	
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = UART4_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=1;		//����ԽСԼ��
	NVIC_InitStructure.NVIC_IRQChannelSubPriority=1;
	NVIC_Init(&NVIC_InitStructure); 
	
	USART_Cmd(UART4,ENABLE);
}

void send_to_phone(uint16_t num)
{
	Serial_SendByte(0x2A);
    Serial_SendByte(0x41);
	while(num > 10)
	{
		Serial_SendByte(num%10+0x30);
		num/=10;
	}
	Serial_SendByte(num+0x30);
}

void send_to_plane(unsigned char Type , unsigned char L0 ,unsigned char L1)
{
    Serial_SendByte(0xAA);
    Serial_SendByte(0xAA);
    Serial_SendByte(0xBB);
    Serial_SendByte(0xCC);
    Serial_SendByte(Type);
    Serial_SendByte(L0);
    Serial_SendByte(L1);
    Serial_SendByte(0x55);
    Serial_SendByte(0x55);
}

void Serial_SendByte(uint8_t Byte)
{
	USART_SendData(UART4,Byte);
	while(USART_GetFlagStatus(UART4,USART_FLAG_TXE)==RESET);
	
}


void Serial_SendArry(uint8_t *Array,uint16_t Length)
{
	uint16_t i;
	for (i=0;i<Length;i++)
	{
		Serial_SendByte(Array[i]);
		
	}
}

void Serial_SendString(char *String)
{
	uint8_t i;
	for(i=0;String[i]!='\0';i++)
	{
		Serial_SendByte(String[i]);
	}
}

uint32_t Serial_Pow(uint32_t x,uint32_t y)
{
	uint32_t result = 1;
	while(y--)
	{
		result = result* x;
	}
	return result;
}

void Serial_SendNumber(uint32_t Number,uint8_t Length)
{
	uint16_t i;
	for(i=0;i<Length;i++)
	{
		Serial_SendByte(Number/Serial_Pow(10,Length-i-1)%10 + 0x30);
	}
	
}
	
void Serial_Printf(char *format,...)
{
	char String[100];
	va_list arg;
	va_start(arg,format);
	vsprintf(String,format,arg);
	va_end(arg);
	Serial_SendString(String);
}

uint8_t Serial_GetRxFlag(void)
{
	if(Serial_RxFlag == 1)
	{
		Serial_RxFlag=0;
		return 1;
	}
	else if(Serial_RxFlag == 2)
	{
		Serial_RxFlag=0;
		return 2;
	}
	return 0;
}

int fputc(int Data, FILE *BUF)
{
	USART_SendData(UART4, Data);
	while ( USART_GetFlagStatus(UART4, USART_FLAG_TXE) == RESET);		
 
	return Data;
}

uint8_t Serial_GetRxData(void)
{
	return Serial_RxData;
}

//uint8_t U4Text[4] = {0};
// A0Z ǰ��
// A1Z ����
// A2Z ��ת
// A3Z ��ת
// A4Z ֹͣ
void UART4_IRQHandler(void)
{
//	static uint8_t num = 0;
	static uint8_t Rxstate =0;
	if(USART_GetFlagStatus(UART4,USART_FLAG_RXNE)==SET)//�ж���û�н��յ�����
	{
//		Usart2_RxFlag = 1;//�������Ҫʹ�ð�ͷ��β���б����ݵ�׼ȷ�Կ��Խ����ע��
		Serial_RxData=USART_ReceiveData(UART4);//���Խ���ͷ��β�Ĵ�����װ�ɺ�����
//		U4Text[num] = Serial_RxData;
//		num++;
		if(Rxstate==0) //������һ�κͺ�߽���                           //�����жϵ������ٶ�
		{
		    if(Serial_RxData==0x41)//�жϰ�ͷ
		    {
		  	    Rxstate=1;//�����ߴ������ 
		    }
		    else
		    {
		        Rxstate = 0;
				U4Mode = 0;
		    }
	    }
		else if(Rxstate==1)
		{
			if (Serial_RxData==0x30)	//ǰ��
			{
				Rxstate=2;
				U4Mode = 1;
			}
			else if (Serial_RxData==0x31)	//����
			{
				Rxstate=2;
				U4Mode = 2;
			}
			else if (Serial_RxData==0x32)	//����
			{
				Rxstate=2;
				U4Mode = 3;
			}
			else if (Serial_RxData==0x33)	//����
			{
				Rxstate=2;
				U4Mode = 4;
			}
			else if (Serial_RxData==0x34)	//ֹͣ
			{
				Rxstate=2;
				U4Mode = 5;
			}
//			else if (Serial_RxData==0x35)	//KP
//			{
//				Rxstate=2;
//				U4Mode = 6;
//			}
//			else if (Serial_RxData==0x36)	//KD
//			{
//				Rxstate=2;
//				U4Mode = 7;
//			}
			else
			{
			    Rxstate = 0;
				U4Mode = 0;
			}
		}
		else if(Rxstate==2)
		{
			if (Serial_RxData==0x5A)
			{
				if (U4Mode==1)	//��ǰ
				{
					U4Flag = 1;
					Rxstate = 0;
					U4Mode = 0;
				}
				else if (U4Mode==2)	//���
				{
					U4Flag = 2;
					Rxstate = 0;
					U4Mode = 0;
				}
				else if (U4Mode==3)	//����
				{
					U4Flag = 3;
					Rxstate = 0;
					U4Mode = 0;
				}
				else if (U4Mode==4)	//����
				{
					U4Flag = 4;
					Rxstate = 0;
					U4Mode = 0;
				}
				else if (U4Mode==5)	//ֹͣ
				{
					U4Flag = 5;
					Rxstate = 0;
					U4Mode = 0;
				}
//				else if (U4Mode==6)	//KP
//				{
//					Rxstate = 3;
//					U4Mode = 0;
//				}
//				else if (U4Mode==7)	//KD
//				{
//					Rxstate = 3;
//					U4Mode = 0;
//				}
			}
//			else if(Rxstate==3)
//			{
//				
//			}
			else
			{
			    Rxstate = 0;
				U4Mode = 0;
			}
		}
	     USART_ClearFlag(UART4,USART_IT_RXNE);
	}
	else if(USART_GetFlagStatus(UART4,USART_FLAG_RXNE)==SET)
	{
		;
	}
}


