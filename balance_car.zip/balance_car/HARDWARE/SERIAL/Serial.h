#ifndef __SERIAL_H_
#define __SERIAL_H_
#include "sys.h"
#include <cstdio>

extern uint16_t BT_POS[3];
extern uint16_t BT_FIR_POS[4];

void Serial_SendByte(uint8_t Byte);
void Serial_Init(void);
void Serial_SendArry(uint8_t *Array,uint16_t Length);
void Serial_SendString(char *String);
void Serial_SendNumber(uint32_t Number,uint8_t Length);
void Serial_Printf(char *format,...);
int fputc(int Data, FILE *BUF);
uint8_t Serial_GetRxFlag(void);
uint8_t Serial_GetRxData(void);
void send_to_plane(unsigned char Type , unsigned char L0 ,unsigned char L1);
void send_to_phone(uint16_t num);

#endif
