#ifndef __PID_H
#define __PID_H

void PID_left_Init(float p,float i,float d);
void PID_right_Init(float p,float i,float d);
float PID_calculation_left(int16_t Encoder_left,int16_t Target_left);
float PID_calculation_right(int16_t Encoder_right,int16_t Target_right);
float PID_position_left(float temp_val,float target_left);
float PID_position_right(float temp_val,float target_right);
int track_PID(void);
//void track_PID(void);
//void track_PID(int pwm,float P);
unsigned char digital_read(void);
void PID_track_Init(float p,float i,float d);
float turn_PID(float current_angle,float Target_angle);
int track_PID(void);
void PID_calculation(int pid_mode,float common);		//��ģʽ��ȥ 
void PID_turn_Init(float p,float i,float d);
void PID_position_Init(float p,float i,float d);

void PID_calculation_postural(float angle);

int balance(float Angle,float Gyro);
int velocity(float Angle);
int Turn_Balance(float Angle);

void Get_grad_membership(float erro, float erro_c);
float Quantization(float maximum, float minimum, float x);
float Inverse_quantization(float maximum, float minimum, float qvalues);
void GetSumGrad(void);
void GetOUT(void);
//float FuzzyPIDcontroller(float e_max, float e_min, float ec_max, float ec_min, float kp_max, float kp_min, float erro, float erro_c,float ki_max,float ki_min,float kd_max,float kd_min);
#endif
