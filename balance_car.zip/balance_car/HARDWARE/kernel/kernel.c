#include "stm32f4xx.h"                  // Device header
#include "sys.h"

//extern short MY_GYRO[3];
//extern int balance_Pwm;
extern Attitude_t g_Attitude;
extern int Time_ULT;
extern uint8_t ULT_Flag;
extern float Encoder_Integral;

float ULT_Distance;
int ULT_PWM;
uint8_t ULT_End = 0;
uint8_t ULT_RUN = 0;

void kernelPoll(void)
{
//	if(ULT_RUN == 0)
//		return;
//	ULT_RUN = 0;
	
//	GPIO_SetBits(GPIOG,GPIO_Pin_10);
//	Delay_us(12);
////	Delay_s(2);
//	GPIO_ResetBits(GPIOG,GPIO_Pin_10);
//	
//	ULT_Distance = Time_ULT*340/100;
////	if (ULT_Distance <= 400 && ULT_Distance >= 200)
//	if (ULT_Distance <= 400)
//	{
////		ULT_PWM = 5.25*(400 - ULT_Distance);
//		ULT_PWM-=5;
////		ULT_End = 1;
//		OLED_ShowSignedNum(1, 1, ULT_PWM, 6);
//	}
////	else if (ULT_Distance > 400 || ULT_Distance <= 200)
//	else if (ULT_Distance > 200)
//	{
////		if (ULT_End == 1)
////		{
////			ULT_End = 0;
//////			Encoder_Integral = 0;
////		}
//		ULT_PWM = 0;
////		OLED_ShowSignedNum(1, 1, ULT_PWM, 6);
//	}
	
//	OLED_ShowSignedNum(1, 1, ULT_PWM, 6);
//	OLED_ShowSignedNum(2, 1, ULT_Distance, 6);
//	OLED_ShowSignedNum(1, 1, Time_ULT, 6);
//	OLED_ShowSignedNum(2, 1, ULT_Flag, 6);
	
//	Delay_s(3);
	
//	mpu_dmp_get_data(&(g_Attitude.pitch),&(g_Attitude.roll),&(g_Attitude.yaw));
//	OLED_ShowSignedNum(2, 1, g_Attitude.yaw, 5);
//	balance_Pwm = balance(-(g_Attitude.pitch), MY_GYRO[1]);
//	if (balance_Pwm > 8400)
//			balance_Pwm = 8400;
//	else if(balance_Pwm < -8400)
//			balance_Pwm = -8400;
//	Motor(balance_Pwm, balance_Pwm);
}
