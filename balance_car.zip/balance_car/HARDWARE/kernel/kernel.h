#ifndef __kernel_H_
#define __kernel_H_

void kernelPoll(void);

#endif
