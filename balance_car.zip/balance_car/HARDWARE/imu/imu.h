#ifndef __imu_H_
#define __imu_H_

#include "stm32f4xx.h"                  // Device header 
#include <math.h> 
#include "mpu6050.h"

typedef struct{
    int16_t accX;
    int16_t accY;
    int16_t accZ;
    int16_t gyroX;
    int16_t gyroY;
    int16_t gyroZ;
    
    int16_t Offset[6];		//��ƽ״̬�µ�ƫ��
    uint8_t Check;		
}MPU6050Manager_t;

extern MPU6050Manager_t g_MPUManager;

#define squa( Sq )        (((float)Sq)*((float)Sq))

typedef struct{
    float roll;
    float pitch;
    float yaw;
}Attitude_t;

typedef struct {  //��Ԫ��
  float q0;
  float q1;
  float q2;
  float q3;
} Quaternion;

//Extern����
extern Attitude_t g_Attitude;
//extern MPU6050Manager_t g_MPUManager;
//��������
float Q_rsqrt(float number);
void ATT_Update(const MPU6050Manager_t *pMpu,Attitude_t *pAngE, float dt);
float GetNormAccz(void);
void GetAngle(Attitude_t *pAngE);
void IMU_Reset(void);

#endif
