#ifndef __ENCODER_H__
#define __ENCODER_H__

void Encoder_left_Init(void);
void Encoder_right_Init(void);
int Read_Speed(int TIMx);
void TIM2_IRQHandler(void);
void TIM3_IRQHandler(void);
int16_t Encoder1_Get(void);
int16_t Encoder2_Get(void);
#endif

