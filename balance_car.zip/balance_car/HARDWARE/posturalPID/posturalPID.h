#ifndef __posturalPID_H_
#define __posturalPID_H_

#include "stm32f4xx.h"                  // Device header
#include "sys.h"
//private:
void Fuzzy_Init(float xe_max, float xe_min, float xec_max, float xec_min, float xkp_max, float xkp_min, float xki_max, float xki_min, float xkd_max, float xkd_min);
void Get_grad_membership(float erro,float erro_c);
void GetSumGrad(void);
void GetOUT(void);
float FuzzyPIDcontroller(float erro);
float Quantization(float maximum,float minimum,float x);
float Inverse_quantization(float maximum, float minimum, float qvalues);

#endif
