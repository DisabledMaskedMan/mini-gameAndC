#include "posturalPID.h"

//�Ƕ�->PWMֵ

unsigned char digital_read(void)	//��·ѭ��ֵ�����ư�λ�洢
{
	unsigned int temp=0;
	temp=GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_0);
	temp=temp*2+GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_1);
	temp=temp*2+GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_0);
	temp=temp*2+GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_1);
	temp=temp*2+GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_2);
	temp=temp*2+GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_3);
	temp=temp*2+GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_4);
	return temp;
}

#define NB -3
#define NM -2
#define NS -1
#define ZO 0
#define PS 1
#define PM 2
#define PB 3

	float e_max;
	float e_min;
	float ec_max;
	float ec_min;
	float kp_max;
	float kp_min;
	float ki_max;
	float ki_min;
	float kd_max;
	float kd_min;

    const int  num_area = 8; //�����������
    float e_membership_values[7] = { -3,-2,-1,0,1,2,3 }; //����e������ֵ
    float ec_membership_values[7] = { -3,-2,-1,0,1,2,3 };//����de/dt������ֵ
    float kp_menbership_values[7] = { -3,-2,-1,0,1,2,3 };//�������kp������ֵ
    float ki_menbership_values[7] = { -3,-2,-1,0,1,2,3 }; //�������ki������ֵ
    float kd_menbership_values[7] = { -3,-2,-1,0,1,2,3 };  //�������kd������ֵ
    float fuzzyoutput_menbership_values[7] = { -3,-2,-1,0,1,2,3 };

	float qerro;                    //����e��Ӧ�����е�ֵ
    float qerro_c;                  //����de/dt��Ӧ�����е�ֵ
    float errosum; 
	
    float e_gradmembership[2];      //����e��������(����ռ��)
    float ec_gradmembership[2];     //����de/dt��������(����ռ��)
    int e_grad_index[2];            //����e�������ڹ����������
    int ec_grad_index[2];           //����de/dt�������ڹ����������
	
    float kp;                       //PID����kp
    float ki;                       //PID����ki
    float kd;                       //PID����kd
	
    float qdetail_kp;               //����kp��Ӧ�����е�ֵ
    float qdetail_ki;               //����ki��Ӧ�����е�ֵ
    float qdetail_kd;               //����kd��Ӧ�����е�ֵ
	
    float qfuzzy_output;  
	
    float detail_kp;                //�������kp
    float detail_ki;                //�������ki
    float detail_kd;                //�������kd
	
    float fuzzy_output; 
	
    float gradSums[7] = {0,0,0,0,0,0,0};
    float KpgradSums[7] = { 0,0,0,0,0,0,0 };   //�������kp�ܵ�������
    float KigradSums[7] = { 0,0,0,0,0,0,0 };   //�������ki�ܵ�������
    float KdgradSums[7] = { 0,0,0,0,0,0,0 };   //�������kd�ܵ�������
//		const float NB=-3,NM=-1.5,NS=-0.5,ZO=0,PS=0.5,PM=1.5,PB=3;
    float  Kp_rule_list[7][7] = {{PB,PB,PM,PM,PM,ZO,ZO},     //kp�����
                                 {PM,PM,PM,PS,PS,ZO,NS},
                                 {PM,PM,PS,PS,ZO,NS,NM},
                                 {PB,PM,PS,ZO,NS,NM,NB},
                                 {PM,PS,ZO,NS,NS,NM,NM},
                                 {PS,ZO,NS,NS,NM,NM,NM},
                                 {ZO,ZO,NM,NM,NM,NB,NB}};

    float  Ki_rule_list[7][7] = {{NB,NB,NM,NM,NS,ZO,ZO},     //ki�����
                                 {NB,NB,NM,NS,NS,ZO,ZO},
                                 {NB,NM,NS,NS,ZO,PS,PS},
                                 {NM,NM,NS,ZO,PS,PM,PM},
                                 {NM,NS,ZO,PS,PS,PM,PB},
                                 {ZO,ZO,PS,PS,PM,PB,PB},
                                 {ZO,ZO,PS,PM,PM,PB,PB}};

    float  Kd_rule_list[7][7] = {{PS,ZO,ZO,PB,PM,PB,PB},    //kd�����
                                 {ZO,NS,ZO,PM,PM,PM,PM},
                                 {ZO,NS,ZO,PS,PS,PM,PS},
                                 {NS,NS,ZO,ZO,ZO,PS,PS},
                                 {NS,NS,NS,NS,ZO,PS,ZO},
                                 {PM,NM,NM,NM,ZO,PS,ZO},
                                 {PB,NB,NM,NB,ZO,ZO,NS}};

    float  Fuzzy_rule_list[7][7] = {{PB,PB,PB,PB,PM,ZO,ZO},  
                                    {PB,PB,PB,PM,PM,ZO,ZO},
                                    {PB,PM,PM,PS,ZO,NS,NM},
                                    {PM,PM,PS,ZO,NS,NM,NM},
                                    {PS,PS,ZO,NM,NM,NM,NB},
                                    {ZO,ZO,ZO,NM,NB,NB,NB},
                                    {ZO,NS,NB,NB,NB,NB,NB}};


void Fuzzy_Init(float xe_max, float xe_min, float xec_max, float xec_min, float xkp_max, float xkp_min, float xki_max, float xki_min, float xkd_max, float xkd_min)
{
	e_max = xe_max;
	e_min = xe_min;
	ec_max = xec_max;
	ec_min = xec_min;
	kp_max = xkp_max;
	kp_min = xkp_min;
	ki_max = xki_max;
	ki_min = xki_min;
	kd_max = xkd_max;
	kd_min = xkd_min;
}
								   
//private:
void Get_grad_membership(float erro,float erro_c)  
{
    if (erro > e_membership_values[0] && erro < e_membership_values[6])
    {
        for (int i = 0; i < num_area - 2; i++)
        {
            if (erro >= e_membership_values[i] && erro <= e_membership_values[i + 1])
            {
                e_gradmembership[0] = -(erro - e_membership_values[i + 1]) / (e_membership_values[i + 1] - e_membership_values[i]);
                e_gradmembership[1] = 1+(erro - e_membership_values[i + 1]) / (e_membership_values[i + 1] - e_membership_values[i]);
                e_grad_index[0] = i;
                e_grad_index[1] = i + 1;
                break;
            }
        }
    }
    else
    {
        if (erro <= e_membership_values[0])
        {
            e_gradmembership[0] = 1;
            e_gradmembership[1] = 0;
            e_grad_index[0] = 0;
            e_grad_index[1] = -1;	//ֻռһ��
        }
        else if (erro >= e_membership_values[6])
        {
            e_gradmembership[0] = 1;
            e_gradmembership[1] = 0;
            e_grad_index[0] = 6;
            e_grad_index[1] = -1;	//ֻռһ��
        }
    }

	//����ͬ��
    if (erro_c > ec_membership_values[0] && erro_c < ec_membership_values[6])
    {
        for (int i = 0; i < num_area - 2; i++)
        {
            if (erro_c >= ec_membership_values[i] && erro_c <= ec_membership_values[i + 1])
            {
                ec_gradmembership[0] = -(erro_c - ec_membership_values[i + 1]) / (ec_membership_values[i + 1] - ec_membership_values[i]);
                ec_gradmembership[1] = 1 + (erro_c - ec_membership_values[i + 1]) / (ec_membership_values[i + 1] - ec_membership_values[i]);
                ec_grad_index[0] = i;
                ec_grad_index[1] = i + 1;
                break;
            }
        }
    }
    else
    {
        if (erro_c <= ec_membership_values[0])
        {
            ec_gradmembership[0] = 1;
            ec_gradmembership[1] = 0;
            ec_grad_index[0] = 0;
            ec_grad_index[1] = -1;
        }
        else if (erro_c >= ec_membership_values[6])
        {
            ec_gradmembership[0] = 1;
            ec_gradmembership[1] = 0;
            ec_grad_index[0] = 6;
            ec_grad_index[1] = -1;
        }
    }

}

void GetSumGrad(void)
{
    for (int i = 0; i <= num_area - 1; i++)
    {
        KpgradSums[i] = 0;
        KigradSums[i] = 0;
		KdgradSums[i] = 0;

    }
  for (int i=0;i<2;i++)
  {
      if (e_grad_index[i] == -1)
      {
       continue;
      }
      for (int j = 0; j < 2; j++)
      {
          if (ec_grad_index[j] != -1)
          {
              int indexKp = Kp_rule_list[e_grad_index[i]][ec_grad_index[j]] + 3;	//��Ӧ�±�ü���
              int indexKi = Ki_rule_list[e_grad_index[i]][ec_grad_index[j]] + 3;
              int indexKd = Kd_rule_list[e_grad_index[i]][ec_grad_index[j]] + 3;
              //gradSums[index] = gradSums[index] + (e_gradmembership[i] * ec_gradmembership[j])* Kp_rule_list[e_grad_index[i]][ec_grad_index[j]];
              KpgradSums[indexKp]= KpgradSums[indexKp] + (e_gradmembership[i] * ec_gradmembership[j]);
              KigradSums[indexKi] = KigradSums[indexKi] + (e_gradmembership[i] * ec_gradmembership[j]);
              KdgradSums[indexKd] = KdgradSums[indexKd] + (e_gradmembership[i] * ec_gradmembership[j]);
          }
          else
          {
            continue;
          }

      }
  }

}

void GetOUT(void)
{
    for (int i = 0; i < num_area - 1; i++)
    {
        qdetail_kp += kp_menbership_values[i] * KpgradSums[i];
        qdetail_ki += ki_menbership_values[i] * KigradSums[i];
        qdetail_kd += kd_menbership_values[i] * KdgradSums[i];
    }
}

//ģ��PID����ʵ�ֺ���/
float FuzzyPIDcontroller(float erro)
{
	static int erro_pre=0,erro_ppre=0;
//	static int Last_error;
	int Ferror_c;
//	u16 temp_data[2] = { 0 };       //���ݻ�����
//	Read_Data(temp_data);
//	if(temp_data[0]==0)
//	{
//	Ferror = -temp_data[1];
//	}
//	else
//	{
//	Ferror = temp_data[1];
//	}
	
//	if ((erro < 5 && erro >= 0) || (erro <= 0 && erro > -5))
//		return 0;
	
	Ferror_c=erro-erro_pre;
	errosum += erro;
	qerro = Quantization(e_max, e_min, erro);
	qerro_c = Quantization(ec_max, ec_min, Ferror_c);
	Get_grad_membership(qerro, qerro_c);
	GetSumGrad();
	GetOUT();
	detail_kp = Inverse_quantization(kp_max, kp_min, qdetail_kp);
	detail_ki = Inverse_quantization(ki_max, ki_min, qdetail_ki);
	detail_kd = Inverse_quantization(kd_max, kd_min, qdetail_kd);
	qdetail_kd = 0;
	qdetail_ki = 0;
	qdetail_kp = 0;
	kp = kp + detail_kp;
	ki = ki + detail_ki;
	kd = kd + detail_kd;
	if (kp >= kp_max)
		kp = kp_max;
	else if (kp <= kp_min)
		kp = kp_min;
	if (ki >= ki_max)
		ki = ki_max;
	else if (ki <= ki_min)
		ki = ki_min;
	if (kd >= kd_max)
		kd = kd_max;
	else if (kd <= kd_min)
		kd = kd_min;
//    if (kp < 0)
//        kp = 0;
//    if (ki < 0)
//        ki = 0;
//    if (kd > 0)
//        kd = 0;
	detail_kp=0;
	detail_ki=0;
	detail_kd=0;
	if (erro < 0)
		erro = -erro;
	OLED_ShowSignedNum(1, 1, (int)kp, 9);
//	float output = kp*(erro - erro_pre) + ki * errosum + kd * (erro - 2 * erro_pre + erro_ppre);
//	float output = kp*(erro - erro_pre) + kd * (erro - 2 * erro_pre + erro_ppre);
	float output = kp*erro + ki * errosum + kd * (erro - erro_pre);
	
//	OLED_ShowSignedNum(2, 1, (int)(kd * (erro - erro_pre)), 9);
	
	erro_pre=erro;
	erro_ppre=erro_pre;
	return output;
}

///����ӳ�亯��///(��erro����erro_xӳ��Ϊ-3 - 3)
float Quantization(float maximum,float minimum,float x)
{
    float qvalues= 6.0f *(x-minimum)/(maximum - minimum)-3;
    //float qvalues=6.0*()
    return qvalues;
   
    //qvalues[1] = 3.0 * ecerro / (maximum - minimum);
}

//������ӳ�亯��(��-3 - 3ӳ��Ϊkp,ki,kd)
float Inverse_quantization(float maximum, float minimum, float qvalues)
{
    float x = (maximum - minimum) *(qvalues + 3)/6 + minimum;
    return x;
}
